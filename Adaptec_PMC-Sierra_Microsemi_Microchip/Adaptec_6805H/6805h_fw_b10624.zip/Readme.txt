--------------------------------------------------------------------
README.TXT

Adaptec ASA-7085H/ASA-7805H/ASA-70165H/ASA-70165He/ASA-71605H/ASA-71605He SAS Host Bus Adapters
Adaptec ASR-6405H/ASR-6805H SAS Host Bus Adapters 

NOTE:  All Adaptec by PMC products are UL listed and for use only with UL listed ITE.

as of April 10, 2014
--------------------------------------------------------------------
Please review this file for important information about issues
and errata that were discovered after completion of the standard
product documentation. In the case of conflict between various
parts of the documentation set, this file contains the most
current information.

The following information is available in this file:

   1. New Features in this Release
   2. Software and Documentation
      2.1   Firmware & Driver Software
      2.2   Documentation
   3. Installation and Setup
      3.1   Installation Instructions
      3.2   uEFI-Mode Setup
      3.3   Windows Installation and Setup
            3.3.1  Windows uEFI-Mode Setup
            3.3.2  Windows 7 Setup Issues
            3.3.3  Windows SBS 2011 Setup Issues
      3.4   Red Hat Linux Installation and Setup 
      3.5   SuSE Linux Installation and Setup      
      3.6   FreeBSD Installation and Setup
      3.7   Ubuntu Installation and Setup
      3.8   Debian Installatin and Setup
      3.9   VMware Installation and Setup
      3.10  Boot Drive Selection
      3.11  Building the Open Source Drivers
      3.12  Resetting the Adapter
   4. Command Line Tool (Adp80xxapp)
   5. Known Limitations
      5.1   Maximum Number of Adapters, Expanders, and Bootable Drives
      5.2   Mixing Series 7 and Series 6 Adapter Models
      5.3   Formatting Limitations for Multiple Drives
      5.4   uEFI BIOS Not Available while Formatting a Drive
      5.5   HDDs Listed in Reverse Order on NewIsys Expanders
      5.6   Expander Slot Mapping Issues
      5.7   Intel System Compatibility Issues 
      5.8   Quantum Tape Drive Compatibility Issues
      5.9   No Activity LED for SATA Drives
      5.10  Blink LED Not Supported for Expanders
      5.11  Suspend/Resume Not Supported on Linux OSs
      5.12  Drives Offline with Default Windows SAN Policy
      5.13  Drive Write Cache Settings
      5.14  RHEL Hotplug Issues
      5.15  FreeBSD Hotplug Issues
      5.16  FreeBSD Hangs when No Devices on HBA
      5.17  SGPIO LED Error Pattern
      
--------------------------------------------------------------------
1. New Features in this Release

   o Support for FreeBSD, Debian Linux, and VMware ESXi 5.5
   
   o Expanded Command Line Utility (Adp80xxapp):
   
     � Flash the HBA firmware
     � Obtain information about the HBA
     � Show PHY status and PHY error counts
     � List devices on the HBA
     � Reset devices and LUNs
     � Manage SGPIO settings
     � Send raw SMP and CDB commands
     
     See the user's guide for more information.
           
   o Support for Tape Drive Autoloaders (Multi-LUN Support)
   
     Allows the HBA driver to discover and issue commands to tape drives 
     in an autoloader. Supported on Windows, Linux, and VMware.

   o Native support for 4K sector drives

     For hard disk drives working in 4K native mode, the disk media
     exposes its 4KB physical sector size to the controller firmware 
     and operating system. Support for 4KB logical sectors within 
     operating systems varies by vendor and OS version.

     NOTE: Only uEFI systems can boot from a 4K sector drive. 4KB 
     sector drives are not supported as a boot device with Legacy 
     (Ctrl-A) BIOS.

   o Bugfixes

--------------------------------------------------------------------
2. Software and Documentation

   2.1 Firmware and Driver Software

       NOTE: You can download the latest versions of firmware, BIOS, 
       driver software and utilities from the Adaptec Web Site at 
       start.adaptec.com.

       o Adaptec Firmware/BIOS/Drivers Version 1.02.00
                               
       Drivers for this release have been tested and certified on
       the following operating systems. You can load the drivers on
       out-of-box operating system versions, the latest service pack, 
       or software update. Compatibility issues may be seen with 
       untested OS versions.
               
       Microsoft Windows Drivers: 
  
       o Windows Server 2012 R2
       o Windows Server 2012 64-bit         
       o Windows Server 2008 R2, 64-bit
       o Windows SBS 2011 (all versions)
       o Windows 7, Windows 8, Windows 8.1 32-bit and 64-bit
          
       Linux Drivers:

       o Red Hat Enterprise Linux 6.4, 6.3, 32-bit and 64-bit
       o SuSE Linux Enterprise Server 11 SP3, 32-bit and 64-bit
       o Ubuntu Linux 12.04, 32-bit and 64-bit
       o Debian Linux 7.2, 7, 32-bit and 64-bit
       
       FreeBSD Drivers:
       
       o FreeBSD 9.1, 9.0

       VMware Drivers:
       
       o VMware ESXi 5.5
                             
   2.2 Documentation 
  
       NOTE: You can download the latest documentation from the Adaptec
       Web Site at start.adaptec.com.

       PDF Format (English/Japanese):
        
       o Adaptec Serial Attached SCSI Host Bus Adapters Installation and User's Guide 

       Text Format:

       o Adaptec SAS Host Bus Adapters README.TXT file
       o Task-specific readmes (see sections 3.3 and 3.11)

--------------------------------------------------------------------
3. Installation and Setup

   3.1 Installation Instructions

       The Adaptec Serial Attached SCSI Host Bus Adapters Installation
       and User's Guide contains complete installation information for 
       the adapters and drivers. It also contains usage information
       for the configuration utility.

   3.2 uEFI-Mode Setup
       
       On servers that support the Unified Extensible Firmware Interface, 
       or uEFI (version 2.10 or higher), you can install the OS and setup
       your HBA from the uEFI BIOS. 
       
       To install the OS, boot the server to uEFI (typically by pressing
       DEL), then insert the OS installation DVD. Assuming the DVD is 
       device fs0, type:
       
       Shell>fs0:
       fs0:> \efi\boot\bootx64.efi
       
       When the installation screen is displayed, follow the on-screen 
       instructions to complete the installation.
    
   3.3 Windows Installation and Setup
   
       Use the following drivers to install the HBA on Windows:
       
       o DRV-HIA-SBS-WIN7-ADAP for Small Business Server 2011 + Win 7 + Win 2008 R2 
       o DRV-HIA-WIN8-WIN2012-ADAP for Win 8 + Win 2012

       For more information, see 'readme_win_spc_stor.txt', available
       at start.adaptec.com.
       
       3.3.1 uEFI-Mode Setup
   
       When installing Windows in uEFI mode, clearing the metadata
       on the HDDs is required if the HDDs are moved from an 
       Adaptec RAID controller to the HBA. Clearing the metadata is
       not required in Legacy mode (non-uEFI). 

       3.3.2 Windows 7 Setup Issues

       When installing Windows 7 (32-bit, 64-bit) on an HBA with
       multiple drives attached, installation continuation, after  
       initial reboot, may take 30-70 minutes to complete. Following
       installation, install the hotfix at the link below:
              
       http://support.microsoft.com/kb/2468345

       3.3.3 Windows SBS 2011 Setup Issues

       o When installing the driver on Windows SBS 2011, it may take 
         1.5-3 hours to complete the OS installation.

       o To avoid a driver installation problem on Windows SBS 2011 
         Essential, MBR (Master Boot Record) partitioning is required.
         
         1. To convert the drive to MBR format, install SBS 2011 Essential
            in Legacy mode, and abort installation once the drive is 
            partitioned.

	 2. Switch to uEFI mode, then install SBS 2011 Essential on 
	    the same drive; installation will complete successfully.        

       o When installing the driver on Windows SBS 2011 Essential, the 
         installer times out before listing all discovered drives. The  
         number of listed drives varies, depending on the drive type (eg,  
         SAS vs SATA). This is a limitation in the Windows SBS installer; 
         the Adaptec device driver detects all attached drives.       
	    
       o Installing Windows SBS 2011 in an expander configuration is
         not supported in uEFI mode.              
       
   3.4 Red Hat Linux Installation and Setup
   
       o When installing the Red Hat driver using the instructions 
         in the user's guide, you may see a message stating that 
         'no drivers were found or the disk has already been loaded'. 
         To complete the installation, click 'Continue', then finish
         the installation normally.
       
       o When installing the Red Hat driver, the first 16 drives in
         the expander (if present) are listed in alphabetical order. 
         To determine the first 8 bootable devices, select "Create 
         Custom Layout" in the installation screen. This will display
         the drives in the order in which they were discovered. 
         You can install the OS on any of the first 8 drives.
    
   3.5 SuSE Linux Installation and Setup

       o After downloading the SLES driver from the Adaptec Web site, 
         execute the following commands to create the HBA iso on 
         the USB drive (assuming the USB drive is /dev/sdd):
         
	 dd if=/dev/zero of =/dev/sdd
	 dd if=pm80xx---.iso of =/dev/sdd  
       
       o SLES 11 x64 detects direct attached drives on the HBA but times 
         out before discovering drives in the expander (due to an 
         OS mapping issue) and fails to boot to the OS.

         WORKAROUND: Remove all drives other than the OS drive and boot  
         up once. Shut down the system, then put back all drives; the OS 
         should boot normally.
         
       o The maximum supported drives in SLES 11 SP3 is 119.

   3.6 FreeBSD Installation and Setup

       o Before installing the HBA driver for FreeBSD, you must build a 
         custom FreeBSD kernel with the 'ahd' driver disabled. Follow 
         these steps:
       
         1. ls to /usr/src/sys/<platform>/conf/     (<platform> is amd64/i386)
         2. cp GENERIC to MYKERNEL
         3. Open the file MYKERNEL, then comment out the ahd option and save the file: 
            #device  ahd
         4. cd to /usr/src/
         5. Compile the kernel: make buildkernel KERNCONF=MYKERNEL
         6. Install the kernel: make installkernel KERNCONF=MYKERNEL
         7. Reboot the computer

       o The maximum supported drives in FreeBSD 9.0 and 9.1 is 48.
       
   3.7 Ubuntu Installation and Setup

       o If Ubuntu x64 fails to boot to the OS after installation, add  
         the OS option 'quiet splash edd=off' in the GRUB bootloader  
         file "menu.lst". The OS should boot normally.
         
       o In a configuration with maximum drives/enclosures, Ubuntu may
         fail to boot with a SATA OS drive.
         
         WORKAROUND: Replace the SATA OS drive with a SAS OS drive.

   3.8 Debian Installatin and Setup
  
       Debian x64 supports a maximum of 24 drives during bootup. After
       booting, it can support up to 128 drives. 

   3.9 VMware Installation and Setup

       VMware supports a maximum of 128 LUNs per target.

  3.10 Boot Drive Selection
   
       NOTE: Use the following procedure for Legacy mode (non-uEFI)  
       boot drive selection. For uEFI-mode boot drive selection, 
       after OS installation, use the system BIOS Boot menu to move  
       the OS image to priority.
       
       Selecting Boot Drive when BBS=Device (default):
       
       If BBS is set to "Device" in the Ctrl+A Configuration utility, you can 
       select any of the first 8 drives as the bootable drive.
       
       1. Power on the system, go to the Ctrl+A utility, select Controller 
          Configuration, then set BBS Support=Device.
       
       2. Go to system BIOS setup menu, set CD/DVD ROM as the first bootable 
          device, then select the HDD on which the OS will be installed  
          as the 2nd bootable device in boot priority. You can choose any 
          of the 8 devices listed.
       
       3. Boot from the OS DVD and load the HBA driver. The installer 
          displays the drives in order. Select the drive for the installation. 
          
          NOTE:�The boot device in the system BIOS and the OS installation 
          device must match. The installer will create the system
          partition on the first bootable device set in the system BIOS.
       
       Selecting Boot Drive when BBS=Controller:
       
       If BBS is set to "Controller" in the Ctrl+A Configuration utility, 
       only the first drive can be set as the bootable drive.
       
       1. Power on the system, go to the Ctrl+A utility, select Controller 
          Configuration, then set BBS Support=Controller.
       
       2. Go to system BIOS setup menu, set CD/DVD ROM as the first bootable 
          device and Controller as the 2nd bootable device in boot priority. 
       
       3. Boot from the OS DVD and load the HBA driver. The installer
          displays the drives in order. Select the 1st drive for
          OS installation. (You cannot select any other drive.)       

  3.11 Building the Open Source Drivers
   
       For complete instructions for building and installing the Linux
       open source drivers, see 'pm80xx_build_procedure.txt',
       available at start.adaptec.com.

  3.12 Resetting the Adapter
  
       Adaptec Host Bus Adapters are reset using the HDA mode jumper on 
       the controller board (see the user's guide for the jumper location 
       on your HBA model). If a HDA reset is required, contact Adaptec 
       Support for assistance.        
       
--------------------------------------------------------------------
4. Command Line Tool (Adp80xxapp)

   The Adp80xxapp command line tool for Windows, Linux, and VMware is
   available for download at start.adaptec.com.
   
   NOTES: 
        
    o The command line tool is not backward compatible with older
      Adaptec HBA driver releases. Adp80xxapp requires the
      latest drivers and firmware to operate correctly.
   
    o On Windows systems, Adp80xxapp requires Admin privileges.

    o The device driver must be installed prior to flashing an HBA
      with the command line tool.  
    
    o The ADP 'phyerr' command is supported on Linux only. 
    
    o The ADP 'phyerr' and 'phystatus' commands are not supported on
      Adaptec Series 6H HBAs.
    
    o For VMware and FreeBSD, only the ADP 'info' and 'fwflash' commands
      are supported. No other command line options are supported on these OSs.
             
--------------------------------------------------------------------
5. Known Limitations

   5.1  Maximum Number of Adapters, Expanders, and Bootable Drives
   
        You can install a maximum of TWO same-series Adaptec HBAs on
        one system (two Series 7 HBAs, two Series 6 HBAs). See 
        Section 5.2 for more information.
       
        Adaptec Series 7H/7He HBAs support a maximum of:
       
        o 8 bootable drives and 2 expanders during boot time (GSM discovery)
        o 128 drives with 5 expanders during PMM under OS control (using drivers)
       
        Adaptec Series 6H HBAs support a maximum of:
       
        o 4 bootable drives and 1 expander during boot time (GSM discovery)
        o 128 drives with 5 expanders during PMM under OS control (using drivers)

   5.2  Mixing Series 7 and Series 6 Adapter Models
   
        In this release, mixing Adaptec Series 7H/7He and Adaptec Series 6H
        HBAs in the same system is not supported. Doing so may cause  
        the BIOS to hang on POST.       
        
   5.3  Formatting Limitations for Multiple Drives
   
        You can format multiple SAS drives only in the BIOS. Formatting 
        multiple SATA drives is not supported.

   5.4  uEFI BIOS Not Available while Formatting a Drive
   
        While formatting a drive with the uEFI BIOS, you cannot 
        perform any other operation until the formatting is complete. 
        Once formatting is complete, the BIOS responds normally.
       
   5.5  HDDs Listed in Reverse Order on NewIsys Expanders
       
        With Adaptec HBAs in NewIsys expanders, PHY numbers and slot numbers
        are listed in reverse order during POST; eg, 12-1 vs 1-12.j
       
   5.6  Expander Slot Mapping Issues
   
        Box/Slot information for Adaptec HBAs is reported incorrectly 
        in some expanders. For Promise J830, DataOn DNS-1400SM, and 
        Miramar 335SAS expanders, the Box/Slot information is shown as
        BoxFF/SlotFF for all slots, instead of Box00/Slot00, and so on.
        In other cases, the Box/Slot mapping is unpredictable.
 
   5.7  Intel System Compatibility Issues
          
        Intel BOXDX79SI motherboards are not supported.
          
   5.8  Quantum Tape Drive Compatibility Issues
        
        After issuing commands to mount and erase a Quantum TC-L52AN (LTO5)
        tape drive, the drive hangs and the operation eventually 
        aborts with the message "/dev/st0: Input/Output error".          
       
   5.9  No Activity LED for SATA Drives
   
        With I/O running, the Activity LED blinks for SAS drives but 
        not SATA drives.

   5.10 Blink LED Not Supported for Expanders
          
        BLINK LED is not supported for expanders. BLINK LED for drives 
        on the expander is available. 
          
   5.11 Suspend/Resume Not Supported on Linux OSs
   
        The driver does not support suspend/resume/hibernate for SAS 
        devices on Linux or Linux/VMware OSs.
                        
   5.12 Drives Offline with Default Windows SAN Policy 
        
        With the default SAN Policy on Windows, a cold reboot leaves
        some disk drives (above drive 8) offline.
       
        Workaround: Enter these commands at the Windows command prompt:
       
        1. diskpart
        2. san policy=onlineall
        3. san
  
   5.13 Drive Write Cache Settings
          
        In this release, setting the drive write cache to enable/disable  
        is limited to the OS tools for Windows and Linux. This feature
        is not available in the HBA BIOS. 
        
        From Windows:
        
        1. Open the "Computer Management" console, then select "Device Manager".
        2. Select "Disk Drives".
        3. Double-click the drive you want to work with, then select "Policies".
        4. Select/unselect "Enable write caching on the device", then click OK.
        5. Reboot the system.
        
        From Linux:
        
        1. Login as root.
        2. Type one of these commands:
                   
           /sbin/hdparm -W 0 /dev/hdX 0     # disable write caching               
           /sbin/hdparm -W 1 /dev/hdX 1     # enable write caching
           
           where X is any logical drive on that system; a/b/c� etc 
 
   5.14 RHEL Hotplug Issues 
 
        o In RHEL 6.4 x64, you must allow at least 20 seconds between 
          hotplugging of disk drives.
       
        o When hotplugging two or more cascaded expanders, RHEL 6.3 will
          detect only one of the expanders. It fails to detect the others.
 
          WORKAROUND: Upgrade to RHEL 6.4.
        
   5.15 FreeBSD Hotplug Issues
      
        If FreeBSD (9.0/9.1, 32-bit) is booted from a disk attached 
        to the HBA, the system hangs when a new disk enclosure is
        hotplugged.

   5.16 FreeBSD Hangs when No Devices on HBA
   
        On FreeBSD systems, the OS fails to boot when no devices are
        connected to the HBAs. 
   
        WORKAROUND: Connect at least one device to the HBA to complete 
        the boot process. 
        
   5.17 SGPIO LED Error Pattern
   
        According to the SGPIO SFF-8485 specification, when the SGPIO 
        code is set to 0x4 and 0x5, the Error indicator is Enabled, 
        ie, set ODn.2 bit to 0. In practice, the Error indicator can
        be enabled only by setting ODn.2 bit to 1. Since the statement
        in the specification is contradictory, code values 0x4 and 0x5
        are not recommended. Use Code 0x0 to disable the error indicator
        and code 0x1 to enable the indicator. 
       
--------------------------------------------------------------------
(c) 2014 PMC-Sierra, Inc. All Rights Reserved. 

This software is protected under international copyright laws and 
treaties. It may only be used in accordance with the terms 
of its accompanying license agreement.

The information in this document is proprietary and confidential to
PMC-Sierra, Inc., and for its customers' internal use. In any event,
no part of this document may be reproduced or redistributed in any
form without the express written consent of PMC-Sierra, Inc.,  
1380 Bordeaux Drive, Sunnyvale, CA 94089.

P/N DOC-01752-03-A Rev. A                                